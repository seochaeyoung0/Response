import React, { useState } from 'react';
import './App.css';

const MOCK_RESULTS = [
  { id: 1, type: 'book', title: '인간 실격', author: '다자이 오사무', status: '대출가능' },
  { id: 2, type: 'book', title: '데미안', author: '헤르만 헤세', status: '예약중' },
  { id: 3, type: 'book', title: '참을 수 없는 존재의 가벼움', author: '밀란 쿤데라', status: '대출가능' },
  { id: 4, type: 'book', title: '1984', author: '조지 오웰', status: '대출가능' },
];

function App() {
  const [searchTerm, setSearchTerm] = useState('');
  const [isSearched, setIsSearched] = useState(false);
  const [currentBookIdx, setCurrentBookIdx] = useState(0);
  const [currentSchematicIdx, setCurrentSchematicIdx] = useState(0);
  const [currentNewsIdx, setCurrentNewsIdx] = useState(0);
  const [recStartIdx, setRecStartIdx] = useState(0);
  const [showModal, setShowModal] = useState(false);
  const [showMenu, setShowMenu] = useState(false);
  const [showLectureDetail, setShowLectureDetail] = useState(false);
  const [selectedItem, setSelectedItem] = useState(null);
  const [selectedLecture, setSelectedLecture] = useState(null);

  const books = [
    { title: "불편한 편의점", author: "김호연 저 | 나무옆의자", img: "/book_cover.png" },
    { title: "이상하고 자유로운 할머니가 되고 싶어", author: "무루 지음 | 오후의소묘", img: "/book_rec1.png" },
    { title: "절창 : 구병모 장편소설", author: "구병모 지음", img: "/book_rec2.png" },
    { title: "이상한 무인오락실", author: "이선희 지음", img: "/book_rec3.png" },
    { title: "균형 잡힌 뇌: 인공지능 시대의 뇌건강", author: "이경민 지음", img: "/book_rec4.png" },
    { title: "(모두를 위한) 한국미술사", author: "김인희 지음", img: "/book_rec5.png" },
    { title: "작별인사", author: "김영하 지음 | 복복서가", img: "/book_rec1.png" },
    { title: "파친코", author: "이민진 지음 | 인플루엔셜", img: "/book_rec2.png" },
    { title: "달러구트 꿈 백화점", author: "이미예 지음 | 팩토리나인", img: "/book_rec3.png" },
    { title: "아몬드", author: "손원평 지음 | 창비", img: "/book_rec4.png" },
    { title: "하얼빈", author: "김훈 지음 | 문학동네", img: "/book_rec5.png" },
  ];

  const schematicImages = [
    { id: 1, img: "/schematic1.png", title: "스마트 열람실 안내" },
    { id: 2, img: "/schematic2.png", title: "공간 활용 가이드" },
    { id: 3, img: "/schematic3.png", title: "디지털 지식 흐름" },
  ];

  const newsImages = [
    { id: 1, img: "/news.png", title: "서울도서관 하계 휴관 안내" },
    { id: 2, img: "/news2.png", title: "6월 저자 초청 강연회" },
    { id: 3, img: "/news3.png", title: "어린이 그림책 읽기 교실" },
    { id: 4, img: "/news4.png", title: "디지털 리터러시 교육" },
  ];

  const lectures = [
    { id: 1, library: "꿈꾸레도서관", title: "[성인] 보드게임 속 수학여행", date: "2026.04.15 ~ 2026.07.08", target: "만 19세 이상", status: "폐강" },
    { id: 2, library: "서울도서관", title: "[어린이] 창의력 쑥쑥 종이접기", date: "2026.05.20 ~ 2026.06.15", target: "만 7세 ~ 만 12세", status: "접수중", location: "어린이실", instructor: "김종이 작가", fee: "무료" },
    { id: 3, library: "강남구립도서관", title: "[성인] 힐링 캘리그라피 기초", date: "2026.06.01 ~ 2026.08.31", target: "만 19세 이상", status: "접수중", location: "문화교실 1", instructor: "이글씨 강사", fee: "10,000원" },
    { id: 4, library: "동작상도국어절도서관", title: "[가족] 주말 그림책 구연 동화", date: "2026.05.10 ~ 2026.05.31", target: "제한없음", status: "접수중", location: "다목적실", instructor: "박동화 성우", fee: "무료" },
  ];

  const nextBook = () => setCurrentBookIdx((prev) => (prev + 1) % books.length);
  const prevBook = () => setCurrentBookIdx((prev) => (prev - 1 + books.length) % books.length);

  const nextSchematic = () => setCurrentSchematicIdx((prev) => (prev + 1) % schematicImages.length);
  const prevSchematic = () => setCurrentSchematicIdx((prev) => (prev - 1 + schematicImages.length) % schematicImages.length);

  const nextNews = () => setCurrentNewsIdx((prev) => (prev + 1) % newsImages.length);
  const prevNews = () => setCurrentNewsIdx((prev) => (prev - 1 + newsImages.length) % newsImages.length);

  const handleSearch = (e) => {
    if (e && e.preventDefault) e.preventDefault();
    if (searchTerm.trim()) {
      setIsSearched(true);
    }
  };

  const openReservation = (item) => {
    setSelectedItem(item);
    setShowModal(true);
  };

  const confirmReservation = () => {
    alert(`${selectedItem.title} 예약이 완료되었습니다.`);
    setShowModal(false);
    setSelectedItem(null);
  };

  return (
    <div className="app">
      {/* Header */}
      <header className="header">
        <div className="header-content">
          <div className="logo-group" aria-label="서울도서관 로고" onClick={() => setIsSearched(false)} style={{ cursor: 'pointer' }}>
            <svg width="32" height="32" viewBox="0 0 40 40" fill="none" xmlns="http://www.w3.org/2000/svg" style={{ marginRight: '12px' }}>
              <circle cx="20" cy="20" r="18" stroke="#1A2B48" stroke-width="2"/>
              <circle cx="20" cy="20" r="16" stroke="#C4A47C" stroke-width="1"/>
              <path d="M12 28H28V26H12V28Z" fill="#1A2B48"/>
              <path d="M14 26V18H15V26H14Z" fill="#1A2B48"/>
              <path d="M18 26V18H19V26H18Z" fill="#1A2B48"/>
              <path d="M21 26V18H22V26H21Z" fill="#1A2B48"/>
              <path d="M25 26V18H26V26H25Z" fill="#1A2B48"/>
              <path d="M12 18L20 13L28 18H12Z" fill="#1A2B48"/>
              <rect x="16" y="20" width="8" height="1.5" fill="#C4A47C"/>
              <rect x="16" y="23" width="8" height="1.5" fill="#C4A47C"/>
            </svg>
            <span className="logo-text">SEOUL LIBRARY</span>
          </div>
          <nav className="nav-links">
            <button className="nav-item" title="나의 공간" aria-label="나의 공간 바로가기">
              <div className="icon-placeholder">
                <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                  <circle cx="12" cy="12" r="9" stroke="currentColor" stroke-width="2"/>
                  <circle cx="12" cy="10" r="3" stroke="currentColor" stroke-width="2"/>
                  <path d="M7 18C7 16.5 8.5 15 12 15C15.5 15 17 16.5 17 18" stroke="currentColor" stroke-width="2" stroke-linecap="round"/>
                </svg>
              </div>
              <span>나의공간</span>
            </button>
            <button className="nav-item" title="로그인" aria-label="로그인 페이지로 이동">
              <div className="icon-placeholder">
                <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                  <path d="M15 3H19C20.1046 3 21 3.89543 21 5V19C21 20.1046 20.1046 21 19 21H15" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
                  <path d="M10 17L15 12L10 7" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
                  <path d="M15 12H3" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
                </svg>
              </div>
              <span>로그인</span>
            </button>
            <button className="nav-item" title="전체 메뉴" aria-label="전체 메뉴 보기" onClick={() => setShowMenu(true)}>
              <div className="icon-placeholder">☰</div>
              <span>메뉴</span>
            </button>
          </nav>
        </div>
      </header>

      {/* Main Content */}
      <main className="hero container">
        {!isSearched ? (
          <>
            <h1 style={{ display: 'none' }}>서울도서관 통합 검색</h1>

            {/* Central Search Input Container */}
            <div className="search-container">
              <form 
                className="search-form" 
                onSubmit={(e) => {
                  e.preventDefault();
                  handleSearch(e);
                }}
              >
                <div className="main-search-icon-wrapper">
                  <svg className="search-icon-svg" width="28" height="28" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                    <circle cx="10.5" cy="10.5" r="6.5" stroke="currentColor" stroke-width="3" stroke-linecap="round"/>
                    <path d="M15.5 15.5L20 20" stroke="currentColor" stroke-width="3" stroke-linecap="round"/>
                  </svg>
                </div>
                <input
                  type="text"
                  className="main-search-input"
                  placeholder="어떤 책을 찾으시나요?"
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  aria-label="도서 검색어 입력"
                />
                <button type="submit" className="main-search-submit-btn" aria-label="검색 실행">
                  검색
                </button>
              </form>
            </div>

            {/* Hero Quick Links Grid */}
            <div className="hero-grid" role="navigation" aria-label="주요 서비스 바로가기">
              <button className="hero-card card-ebook" aria-label="전자책 및 오디오북 서비스">
                <div className="card-icon">
                  <svg width="32" height="32" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                    <rect x="3" y="4" width="18" height="12" rx="2" stroke="currentColor" stroke-width="2"/>
                    <path d="M9 20H15M12 16V20" stroke="currentColor" stroke-width="2" stroke-linecap="round"/>
                    <path d="M8.5 10L11 12.5L16 7.5" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"/>
                  </svg>
                </div>
                <span>전자책 / 오디오북</span>
              </button>
              <button className="hero-card card-loan" aria-label="대출 내역 조회 및 연장 서비스">
                <div className="card-icon">
                  <svg width="32" height="32" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                    <path d="M12 19V5M12 5C10.5 5 7 5 3 7V21C7 19 10.5 19 12 19M12 5C13.5 5 17 5 21 7V21C17 19 13.5 19 12 19" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"/>
                  </svg>
                </div>
                <span>대출조회 / 연장</span>
              </button>
              <button className="hero-card card-location" aria-label="도서관 이용시간 및 위치 안내">
                <div className="card-icon">
                  <svg width="32" height="32" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                    <path d="M12 2C8.13 2 5 5.13 5 9C5 14.25 12 22 12 22C12 22 19 14.25 19 9C19 5.13 15.87 2 12 2Z" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
                    <circle cx="12" cy="9" r="3" stroke="currentColor" stroke-width="1.5"/>
                    <path d="M12 7.5V9H13.5" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
                  </svg>
                </div>
                <span>이용시간 / 위치</span>
              </button>
              <button className="hero-card card-facility" aria-label="도서관 시설 이용 예약">
                <div className="card-icon">
                  <svg width="32" height="32" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                    <rect x="4" y="4" width="14" height="16" rx="2" stroke="currentColor" stroke-width="2"/>
                    <path d="M8 4V2H19C20.1046 2 21 2.89543 21 4V16H19" stroke="currentColor" stroke-width="2" stroke-linecap="round"/>
                    <path d="M4 16H18" stroke="currentColor" stroke-width="2"/>
                  </svg>
                </div>
                <span>시설이용</span>
              </button>
              <button className="hero-card card-disabled" aria-label="장애인 전용 서비스">
                <div className="card-icon">
                  <svg width="32" height="32" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                    <circle cx="12" cy="7" r="3" stroke="currentColor" stroke-width="2"/>
                    <path d="M6 21V19C6 16.7909 7.79086 15 10 15H14C16.2091 15 18 16.7909 18 19V21" stroke="currentColor" stroke-width="2" stroke-linecap="round"/>
                    <circle cx="17" cy="9" r="2.5" stroke="currentColor" stroke-width="2"/>
                    <path d="M22 21V20C22 18.3431 20.6569 17 19 17" stroke="currentColor" stroke-width="2" stroke-linecap="round"/>
                    <circle cx="7" cy="9" r="2.5" stroke="currentColor" stroke-width="2"/>
                    <path d="M2 21V20C2 18.3431 3.34315 17 5 17" stroke="currentColor" stroke-width="2" stroke-linecap="round"/>
                  </svg>
                </div>
                <span>장애인 서비스</span>
              </button>
              <button className="hero-card card-smart" aria-label="스마트 도서관 위치 및 정보">
                <div className="card-icon">
                  <svg width="32" height="32" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                    <path d="M12 2C9.5 2 7.5 4 7.5 6.5C7.5 10 12 15 12 15C12 15 16.5 10 16.5 6.5C16.5 4 14.5 2 12 2Z" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
                    <circle cx="12" cy="6.5" r="1.5" stroke="currentColor" stroke-width="1.2"/>
                    <path d="M4 18L12 21L20 18" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
                    <path d="M4 15L12 18L20 15" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
                    <path d="M4 15V18M20 15V18" stroke="currentColor" stroke-width="2" stroke-linecap="round"/>
                  </svg>
                </div>
                <span>스마트 도서관</span>
              </button>
            </div>

            {/* Library Schematic Carousel */}
            <section className="schematic-section">
              <div className="section-header">
                <h3>도서관 이용 도식</h3>
              </div>
              <div className="schematic-container">
                <div className="schematic-slider" style={{ transform: `translateX(-${currentSchematicIdx * 100}%)` }}>
                  {schematicImages.map((item) => (
                    <div key={item.id} className="schematic-slide">
                      <img src={item.img} alt={item.title} className="schematic-img" />
                      <div className="schematic-info">
                        <h4>{item.title}</h4>
                      </div>
                    </div>
                  ))}
                </div>

                <button className="schematic-nav prev" onClick={prevSchematic} aria-label="이전 도식">‹</button>
                <button className="schematic-nav next" onClick={nextSchematic} aria-label="다음 도식">›</button>

                <div className="schematic-dots">
                  {schematicImages.map((_, idx) => (
                    <button
                      key={idx}
                      className={`dot ${idx === currentSchematicIdx ? 'active' : ''}`}
                      onClick={() => setCurrentSchematicIdx(idx)}
                      aria-label={`${idx + 1}번 페이지로 이동`}
                    />
                  ))}
                </div>
              </div>
            </section>

            {/* Library News Carousel */}
            <section className="news-section">
              <div className="news-header">
                <h3>도서관 소식</h3>
              </div>
              <div className="news-content">
                <div className="news-slider" style={{ transform: `translateX(-${currentNewsIdx * 100}%)` }}>
                  {newsImages.map((item) => (
                    <div key={item.id} className="news-slide">
                      <img src={item.img} alt={item.title} className="news-image" />
                    </div>
                  ))}
                </div>
                <div className="news-overlay">
                  <div className="carousel-controls">
                    <span className="pagination">{currentNewsIdx + 1} / {newsImages.length}</span>
                    <button className="control-btn" aria-label="일시정지">⏸</button>
                    <div className="nav-group">
                      <button className="control-btn" aria-label="이전 소식" onClick={prevNews}>◀</button>
                      <button className="control-btn" aria-label="다음 소식" onClick={nextNews}>▶</button>
                    </div>
                  </div>
                </div>
              </div>
            </section>

            {/* Cultural Lectures Section */}
            <section className="lectures-section">
              <div className="section-header">
                <h3>도서관 문화강좌</h3>
                <button className="section-more-btn" aria-label="문화강좌 더보기">
                  <svg width="34" height="34" viewBox="0 0 34 34" fill="none" xmlns="http://www.w3.org/2000/svg">
                    <circle cx="17" cy="17" r="15" fill="#B0B0B0"/>
                    <path d="M15 12L20 17L15 22" stroke="white" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"/>
                  </svg>
                </button>
              </div>

              <div className="filter-row">
                <div className="library-dropdown">
                  <span>전체도서관</span>
                  <span className="dropdown-arrow">▼</span>
                </div>
              </div>

              <div className="tabs-container">
                <button className="tab active">전체</button>
                <button className="tab">접수중</button>
                <button className="tab">접수예정</button>
              </div>

              <div className="lectures-grid">
                {lectures.map((lecture) => (
                  <div
                    key={lecture.id}
                    className={`lecture-card ${lecture.status === '접수중' ? 'clickable' : ''}`}
                    onClick={() => {
                      if (lecture.status === '접수중') {
                        setSelectedLecture(lecture);
                        setShowLectureDetail(true);
                      }
                    }}
                  >
                    <div className="lecture-library">{lecture.library}</div>
                    <h4 className="lecture-title">{lecture.title}</h4>
                    <div className="lecture-info">
                      <div className="info-item">
                        <span className="info-icon">
                          <svg width="16" height="16" viewBox="0 0 20 21" fill="none" xmlns="http://www.w3.org/2000/svg">
                            <rect x="3" y="4" width="14" height="13" rx="1.5" stroke="currentColor" stroke-width="1.5"/>
                            <path d="M3 8H17" stroke="currentColor" stroke-width="1.5"/>
                            <path d="M6 3V5" stroke="currentColor" stroke-width="1.5" stroke-linecap="round"/>
                            <path d="M14 3V5" stroke="currentColor" stroke-width="1.5" stroke-linecap="round"/>
                          </svg>
                        </span>
                        <span>{lecture.date}</span>
                      </div>
                      <div className="info-item">
                        <span className="info-icon">
                          <svg width="16" height="16" viewBox="0 0 20 17" fill="none" xmlns="http://www.w3.org/2000/svg">
                            <circle cx="7" cy="6" r="3" stroke="currentColor" stroke-width="1.5"/>
                            <path d="M2 14C2 12.3431 3.34315 11 5 11H9C10.6569 11 12 12.3431 12 14" stroke="currentColor" stroke-width="1.5"/>
                            <path d="M13 11H15C16.6569 11 18 12.3431 18 14" stroke="currentColor" stroke-width="1.5"/>
                            <circle cx="13" cy="6" r="2.5" stroke="currentColor" stroke-width="1.5"/>
                          </svg>
                        </span>
                        <span>{lecture.target}</span>
                      </div>
                    </div>
                    <div className={`lecture-status ${lecture.status === '접수중' ? 'badge-active' : 'badge-closed'}`}>
                      {lecture.status}
                    </div>
                  </div>
                ))}
              </div>

              {/* Pagination/Play Controls for Lectures */}
              <div className="lectures-controls">
                <div className="control-bar">
                  <button className="arrow-btn">◀</button>
                  <button className="pause-btn">⏸</button>
                  <button className="arrow-btn">▶</button>
                </div>
              </div>
            </section>

            {/* Now, This Book Section */}
            <section className="now-book-section">
              <div className="section-header">
                <h3>지금, 이 책</h3>
              </div>

              <div className="book-tabs">
                <button className="tab active">추천도서</button>
                <button className="tab">신착도서</button>
                <button className="tab">인기도서</button>
              </div>

              <div className="book-display">
                <div className="book-cover-container" key={currentBookIdx}>
                  <img src={books[currentBookIdx].img} alt={`${books[currentBookIdx].title} 책 표지`} className="book-cover-img fade-in" />
                  <div className="book-meta">
                    <h4 className="book-title">{books[currentBookIdx].title}</h4>
                    <p className="book-author">{books[currentBookIdx].author}</p>
                  </div>
                </div>
              </div>

              <div className="recommendations-container">
                <div className="recommendations-grid">
                  {[0, 1, 2].map((offset) => {
                    const book = books[(currentBookIdx + offset) % books.length];
                    return (
                      <div key={`${book.title}-${offset}`} className="rec-card fade-in">
                        <img src={book.img} alt={book.title} className="rec-img" />
                        <div className="rec-info">
                          <p className="rec-title">{book.title}</p>
                          <p className="rec-author">{book.author.split(' | ')[0]}</p>
                        </div>
                      </div>
                    );
                  })}
                </div>
              </div>

              <div className="book-controls">
                <div className="control-bar">
                  <button className="arrow-btn" onClick={prevBook}>◀</button>
                  <button className="pause-btn">⏸</button>
                  <button className="arrow-btn" onClick={nextBook}>▶</button>
                </div>
              </div>
            </section>

            {/* Site Footer */}
            <footer className="site-footer">
              <div className="footer-links">
                <button className="footer-link-item">
                  <span>도서관 소개</span>
                  <span className="arrow">›</span>
                </button>
                <button className="footer-link-item">
                  <span>도서관 정책</span>
                  <span className="arrow">›</span>
                </button>
                <button className="footer-link-item">
                  <span>운영규정 / 이용정책</span>
                  <span className="arrow">›</span>
                </button>
                <button className="footer-link-item">
                  <span>도서관 네트워크 / 협력</span>
                  <span className="arrow">›</span>
                </button>
                <button className="footer-link-item">
                  <span>공공도서관 정보</span>
                  <span className="arrow">›</span>
                </button>
              </div>

              <div className="footer-social">
                <button className="social-icon facebook" title="페이스북">f</button>
                <button className="social-icon youtube" title="유튜브">▶</button>
                <button className="social-icon instagram" title="인스타그램" aria-label="서울도서관 인스타그램 바로가기">
                  <svg width="24" height="24" viewBox="0 0 16 16" fill="none" xmlns="http://www.w3.org/2000/svg">
                    <rect width="16" height="16" rx="4" fill="url(#footer_insta_grad)"/>
                    <rect x="3" y="3" width="10" height="10" rx="2.5" stroke="white" stroke-width="1.2"/>
                    <circle cx="8" cy="8" r="2.5" stroke="white" stroke-width="1.2"/>
                    <circle cx="11.5" cy="4.5" r="0.8" fill="white"/>
                    <defs>
                      <linearGradient id="footer_insta_grad" x1="0" y1="16" x2="16" y2="0" gradientUnits="userSpaceOnUse">
                        <stop stop-color="#FFD600"/>
                        <stop offset="0.5" stop-color="#FF0069"/>
                        <stop offset="1" stop-color="#7638FF"/>
                      </linearGradient>
                    </defs>
                  </svg>
                </button>
              </div>

              <div className="footer-contact">
                <p className="contact-title">서울도서관</p>
                <address>서울특별시 중구 세종대로 110</address>
                <p>전화번호 : 02-120, 02-2133-0300, 02-2133-0301</p>
                <p>이용시간 : 화~금 09:00~21:00 / 토, 일 09:00~18:00 / 월요일, 공휴일 휴관</p>
              </div>
            </footer>
          </>
        ) : (
          <div className="results-view">
            <div className="results-header">
              <button className="back-button" onClick={() => setIsSearched(false)} aria-label="메인 페이지로 돌아가기">
                <span className="back-icon">‹</span>
              </button>
              <form className="results-search-bar" onSubmit={handleSearch}>
                <input
                  type="text"
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  placeholder="도서명, 저자명 검색"
                />
                <button type="submit" className="results-search-btn" aria-label="검색">
                  <svg className="search-icon-svg" width="20" height="20" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                    <circle cx="10.5" cy="10.5" r="6.5" stroke="currentColor" stroke-width="2.5" stroke-linecap="round"/>
                    <path d="M15.5 15.5L20 20" stroke="currentColor" stroke-width="2.5" stroke-linecap="round"/>
                  </svg>
                </button>
              </form>
            </div>

            <div className="results-layout">
              {/* Sidebar Navigation */}
              <aside className="results-sidebar">
                <h2 className="sidebar-title">도서검색</h2>
                <nav className="sidebar-nav">
                  <button className="nav-link active">간략검색</button>
                  <button className="nav-link">상세검색</button>
                  <button className="nav-link">신착도서</button>
                  <button className="nav-link">추천도서</button>
                  <button className="nav-link">인기도서</button>
                </nav>
              </aside>

              {/* Main Content Area */}
              <div className="results-main">
                <div className="results-filters">
                  <button className="filter-tab active">전체 (4)</button>
                  <button className="filter-tab">일반도서 (2)</button>
                  <button className="filter-tab">아동도서 (1)</button>
                  <button className="filter-tab">참고도서 (1)</button>
                </div>

                <div className="results-stats">
                  <span><strong>'간략검색'</strong> 결과 총 <strong>4</strong>건</span>
                  <div className="sort-dropdown">
                    <span>정확도순</span>
                    <span className="arrow">▼</span>
                  </div>
                </div>

                <div className="results-list">
                  {MOCK_RESULTS.map((item) => (
                    <div key={item.id} className="result-item-card">
                      <div className="item-thumbnail">
                        {item.type === 'book' ? (
                          <img src={`/book_rec${item.id}.png`} alt={item.title} onError={(e) => e.target.src = '/book_cover.png'} />
                        ) : (
                          <div className="type-icon-placeholder">{item.type === 'program' ? '📅' : '📢'}</div>
                        )}
                      </div>
                      <div className="item-details">
                        <div className="item-meta">
                          <span className={`type-badge ${item.type}`}>
                            {item.type === 'book' ? '도서' : item.type === 'program' ? '프로그램' : '공지'}
                          </span>
                          {item.status && <span className={`status-badge ${item.status === '대출가능' ? 'available' : 'reserved'}`}>{item.status}</span>}
                        </div>
                        <h3 className="item-title">{item.title}</h3>
                        {item.author && <p className="item-author">{item.author}</p>}
                        {item.date && <p className="item-date">일시: {item.date}</p>}

                        <div className="item-actions">
                          {item.type === 'book' ? (
                            <>
                              <button className="btn-action primary" onClick={() => openReservation(item)} disabled={item.status !== '대출가능'}>
                                {item.status === '대출가능' ? '대출예약' : '예약중'}
                              </button>
                              <button className="btn-action secondary">상세보기</button>
                            </>
                          ) : (
                            <button className="btn-action primary">신청하기</button>
                          )}
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          </div>
        )}
      </main>

      {/* Full Menu Overlay */}
      {showMenu && (
        <div className="menu-overlay">
          <div className="menu-content">
            <div className="menu-header">
              <div className="menu-logo">
                <svg width="32" height="32" viewBox="0 0 40 40" fill="none" xmlns="http://www.w3.org/2000/svg" style={{ marginRight: '8px' }}>
                  <circle cx="20" cy="20" r="18" stroke="#1A2B48" stroke-width="2"/>
                  <circle cx="20" cy="20" r="16" stroke="#C4A47C" stroke-width="1"/>
                  <path d="M12 28H28V26H12V28Z" fill="#1A2B48"/>
                  <path d="M14 26V18H15V26H14Z" fill="#1A2B48"/>
                  <path d="M18 26V18H19V26H18Z" fill="#1A2B48"/>
                  <path d="M21 26V18H22V26H21Z" fill="#1A2B48"/>
                  <path d="M25 26V18H26V26H25Z" fill="#1A2B48"/>
                  <path d="M12 18L20 13L28 18H12Z" fill="#1A2B48"/>
                  <rect x="16" y="20" width="8" height="1.5" fill="#C4A47C"/>
                  <rect x="16" y="23" width="8" height="1.5" fill="#C4A47C"/>
                </svg>
                SEOUL LIBRARY
              </div>
              <button className="menu-close-btn" onClick={() => setShowMenu(false)}>✕</button>
            </div>

            <div className="menu-grid">
              <div className="menu-category">
                <h3>도서검색</h3>
                <ul>
                  <li><button onClick={() => { setIsSearched(true); setShowMenu(false); }}>간략검색</button></li>
                  <li>상세검색</li>
                  <li>신착도서</li>
                  <li>추천도서</li>
                </ul>
              </div>
              <div className="menu-category">
                <h3>이용자마당</h3>
                <ul>
                  <li>공지사항</li>
                  <li>자주하는 질문</li>
                  <li>Q&A</li>
                  <li>시민의 소리</li>
                </ul>
              </div>
              <div className="menu-category">
                <h3>문화행사</h3>
                <ul>
                  <li>문화강좌 신청</li>
                  <li>강좌 일지</li>
                  <li>행사 안내</li>
                  <li>전시 안내</li>
                </ul>
              </div>
              <div className="menu-category">
                <h3>도서관소개</h3>
                <ul>
                  <li>인사말</li>
                  <li>연혁</li>
                  <li>조직/직원</li>
                  <li>시설안내</li>
                </ul>
              </div>
            </div>

            <div className="menu-footer">
              <div className="menu-user-links">
                <button>로그인</button>
                <button>회원가입</button>
                <button>나의공간</button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Lecture Detail Overlay */}
      {showLectureDetail && selectedLecture && (
        <div className="lecture-overlay">
          <div className="lecture-detail-content">
            <div className="detail-header">
              <button className="detail-back-btn" onClick={() => setShowLectureDetail(false)}>←</button>
              <h2>문화강좌 상세</h2>
            </div>

            <div className="detail-banner">
              <img src="/lecture_banner.png" alt="강좌 배너" />
              <div className="detail-status-badge">{selectedLecture.status}</div>
            </div>

            <div className="detail-body">
              <div className="detail-title-section">
                <span className="detail-library">{selectedLecture.library}</span>
                <h3 className="detail-title">{selectedLecture.title}</h3>
              </div>

              <div className="detail-info-grid">
                <div className="detail-info-item">
                  <span className="label">강사명</span>
                  <span className="value">{selectedLecture.instructor}</span>
                </div>
                <div className="detail-info-item">
                  <span className="label">교육장소</span>
                  <span className="value">{selectedLecture.location}</span>
                </div>
                <div className="detail-info-item">
                  <span className="label">교육기간</span>
                  <span className="value">{selectedLecture.date}</span>
                </div>
                <div className="detail-info-item">
                  <span className="label">참가비</span>
                  <span className="value">{selectedLecture.fee}</span>
                </div>
                <div className="detail-info-item">
                  <span className="label">참가대상</span>
                  <span className="value">{selectedLecture.target}</span>
                </div>
              </div>

              <div className="detail-description">
                <h4>강좌소개</h4>
                <p>본 강좌는 시민 여러분의 문화 소양 함양을 위해 서울도서관에서 기획한 특별 프로그램입니다. 각 분야 전문가와 함께하는 깊이 있는 학습 기회를 놓치지 마세요.</p>
              </div>
            </div>

            <div className="detail-footer">
              <button className="apply-btn" onClick={() => alert('수강 신청이 완료되었습니다.')}>수강 신청하기</button>
            </div>
          </div>
        </div>
      )}

      {/* Reservation Modal */}
      {showModal && (
        <div className="modal-overlay">
          <div className="modal-content">
            <h3>도서 예약 확인</h3>
            <p><strong>{selectedItem?.title}</strong> 도서를 예약하시겠습니까?</p>
            <div className="modal-actions">
              <button className="btn-secondary" onClick={() => setShowModal(false)}>취소</button>
              <button className="btn-primary" onClick={confirmReservation}>확인</button>
            </div>
          </div>
        </div>
      )}

      <footer className="footer">
        <div className="container">
          <p>© 2026 Seoul Library. All Rights Reserved. Designed for better accessibility.</p>
        </div>
      </footer>
    </div>
  );
}

export default App;
