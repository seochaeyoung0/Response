
$paths = @(
    "C:\Program Files\nodejs\node.exe",
    "C:\Program Files (x86)\nodejs\node.exe",
    "$env:APPDATA\npm\node.exe",
    "$env:LOCALAPPDATA\nvs\default\node.exe",
    "$env:USERPROFILE\.nvm\versions\node\*\bin\node.exe"
)

foreach ($path in $paths) {
    if (Test-Path $path) {
        Write-Output "Found node at: $path"
        exit 0
    }
}

Write-Output "Node not found in common paths."
exit 1
